### Writing email
To HR@MARA.com
Name : Sahassawat Suksusiang, Email : i.morkey@msn.com.
Address : 88/63, Moo 1, BangSrimuang19, Mueng Nonthaburi, Nonthaburi, Thailand.
Phone number : +66834475163

Education:
Highest level of education : Bachelor's Degree
Qualification : Bachelor of Computer Engineering