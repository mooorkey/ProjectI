Why use bitcoin? bitcoin is "peer to peer" which means no ==trusted central authority== to avoid fee(The cost of mediation increases transaction costs)

Satoshi
What - Electronic Cash System
Why - 
How -  use cryptography to protect ==digital signature==  
***
- Task 1
	"PGP" - pretty good privacy
	"GPG" - ทดลองส่ง email
	ส่ง Email หาเพื่อนในกลุ่ม แนบ Digital Signature ไปด้วย
- Task 2
	Download ISO file and investigate digital signature file ==จะรู้ได้ยังไงว่า digital signature ไม่ถูกแก้ไข==
- Task 3
	Transaction
- Task 4
	Proof-of-Work
อัด Video ลง Youtube พูดถึง Step ในการทำว่าทำยังไง
***
